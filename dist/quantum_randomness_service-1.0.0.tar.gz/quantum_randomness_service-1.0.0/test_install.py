from qrandom import QuantumRandom
client = QuantumRandom()
print(client.get_random_sync())
